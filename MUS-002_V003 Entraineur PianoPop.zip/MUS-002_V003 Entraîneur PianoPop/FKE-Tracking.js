// Call once per launch, only after consent. Use a dedicated named Firebase app.
const defaultConfig = {"apiKey": "AIzaSyBc0D6iIr0OchMTTKDFCJjINQkmcEf3Bxk", "authDomain": "adm-001-administration.firebaseapp.com", "projectId": "adm-001-administration", "storageBucket": "adm-001-administration.firebasestorage.app", "messagingSenderId": "337568488890", "appId": "1:337568488890:web:2a69377d1f007a8dab9183", "databaseURL": "https://adm-001-administration-default-rtdb.europe-west1.firebasedatabase.app/"};
export async function trackLaunch({config=defaultConfig,project,version,consent=false,geo=false,tool="launch"}) {
 if(!consent)return;
 if(!/^[A-Z]{3}-[0-9]{3}$/.test(project)||!/^V[0-9]{3}$/.test(version))return;
 const key='fke-pending-'+project;
 try {
 const [{initializeApp,getApps},{getAuth,signInAnonymously},{getDatabase,ref,push,set,serverTimestamp}]=await Promise.all(['app','auth','database'].map(x=>import('https://www.gstatic.com/firebasejs/11.10.0/firebase-'+x+'.js')));
 const app=getApps().find(a=>a.name==='FKE-ADM')||initializeApp(config,'FKE-ADM');
 const auth=getAuth(app);await auth.authStateReady();const user=auth.currentUser||(await signInAnonymously(auth)).user;
 const ua=navigator.userAgent;const device=/iPhone|iPad|iPod/.test(ua)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1)?'iOS':/Android/.test(ua)?'Android':/Windows/.test(ua)?'Windows':/Mac/.test(ua)?'macOS':'Autre';
 let incident=localStorage.getItem(key)||'',country='',region='';
 if(incident)incident+=' | Collecte rétablie '+new Date().toISOString();
 if(geo){try{const r=await fetch('https://ipapi.co/json/',{signal:AbortSignal.timeout(3500),credentials:'omit'});if(!r.ok)throw Error('HTTP '+r.status);const j=await r.json();if(j.error)throw Error('service indisponible');country=String(j.country_name||'').slice(0,80);region=String(j.region||'').slice(0,100);if(localStorage.getItem(key+'-geo')){incident+=' | Géolocalisation rétablie; '+localStorage.getItem(key+'-geo');localStorage.removeItem(key+'-geo');}}catch(e){const previous=localStorage.getItem(key+'-geo')||new Date().toISOString();localStorage.setItem(key+'-geo',previous);incident+=' | Géolocalisation indisponible depuis '+previous;}}
 await Promise.race([set(push(ref(getDatabase(app),'events/'+user.uid)),{project,version,device,tool,time:serverTimestamp(),country,region,incident:incident.slice(0,200)}),new Promise((_,reject)=>setTimeout(()=>reject(Error('délai dépassé')),7000))]);localStorage.removeItem(key);
 }catch(e){try{if(!localStorage.getItem(key))localStorage.setItem(key,'Collecte interrompue '+new Date().toISOString()+' : '+String(e.code||e.message).slice(0,90));}catch{}}
}
